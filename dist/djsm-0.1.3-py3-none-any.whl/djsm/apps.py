from django.apps import AppConfig


class DJSMConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djsm'
